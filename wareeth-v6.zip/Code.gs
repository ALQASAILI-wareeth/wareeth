/**
 * تطبيق وريث – الخادم (Google Apps Script) – الإصدار 4
 * يحفظ الحركات في الشيت، ويرسل الإشعارات، ويدير الإقفال السنوي.
 *
 * الأرقام السرية مو هنا: هي في ملف ثاني اسمه "الأرقام" داخل نفس المشروع،
 * فأي تحديث لهذا الملف ما يحتاج تكتبها من جديد.
 */
 
const SHEET_ID = '19lwBQ780sUeBWdUkb4uiK8jCVQr-FNQ3zmq6QBNe5n8'; // شيت "وريث – قاعدة البيانات"
let SS_ = null, CLOSINGS_ = null;
const ss_ = () => SS_ || (SS_ = SpreadsheetApp.openById(SHEET_ID));
const CHECKED_ = {};
const TX_SHEET = 'الحركات';
const CFG_SHEET = 'الإعدادات';
const REQ_SHEET = 'بانتظار الاعتماد';
const MAX_FAILS = 10;        // محاولات غلط مسموحة لكل جهاز قبل ما ينقفل
const LOCK_SECONDS = 1800;   // مدة قفل الجهاز (نص ساعة)
const REQUIRE_DISTINCT_PINS = true; // غيّرها لـ true لما تبي السيرفر يرفض الأرقام المتشابهة
function lockGen_() { return PropertiesService.getScriptProperties().getProperty('lockGen_') || '0'; }
const CLOSE_SHEET = 'الإقفالات';
const CLOSE_HEAD = ['المعرف','السنة','تاريخ الإقفال','تجريبي','رصيد البناية','رصيد البنك – البناية','رصيد المزارع','رصيد البنك – المزارع','الإجمالي','ملحوظة','أعدّه','وقت الإعداد','اعتمده','وقت الاعتماد','الحالة','البيانات'];
const REQ_HEAD = ['رقم الطلب','العملية','المعرف','البيانات','بواسطة','وقت الطلب','الطالب','الحالة','وقت القرار'];
const HEIRS = ['may','rashed','saeed','ali','eid','mohamed','naser','bakheeta','hamda','shamma','madhheya','noura'];
const HEIR_NAMES = ['مي','راشد','سعيد','علي','عيد','محمد','ناصر','بخيتة','حمدة','شمة','مضحية','نورة'];
const HEAD = ['المعرف','التاريخ','الحساب','النوع','المبلغ','من / الجهة','ملحوظة','توزيع سابق','أنشئ','عُدّل'].concat(HEIR_NAMES).concat(['صاحب الإدخال','العقار','ملغاة']);
const OWNER_COL = 11 + HEIR_NAMES.length;   // عمود "صاحب الإدخال"
const PROP_COL = OWNER_COL + 1;             // عمود "العقار"
const PROP_SHEET = 'العقارات';
const PROP_HEAD = ['المعرف','الاسم','الحساب','رقم الأرض','الموقع','المساحة م²','الاستخدام','عنوان القسيمة','تاريخ التخصيص','المصدر','الحصص %','مخفي','أنشئ','عُدّل'];
const ACCT_AR = {bld:'البناية', farm:'المزارع', old:'سابق'};
const KIND_AR = {dep:'إيداع', exp:'مصروف', dist:'توزيع'};
const inv = o => Object.keys(o).reduce((a,k)=>(a[o[k]]=k,a),{});
const ACCT_KEY = inv(ACCT_AR), KIND_KEY = inv(KIND_AR);
 
// يفك قفل الدخول بعد محاولات الرقم السري الغلط (شغّلها من المحرر: اختر unlock ثم تشغيل)
function unlock_() {
  PropertiesService.getScriptProperties().deleteProperty('loginAttempts');
  const pr = PropertiesService.getScriptProperties();
  pr.setProperty('lockGen_', String(+(pr.getProperty('lockGen_') || 0) + 1));
  CacheService.getScriptCache().remove('f:all');
  Logger.log('انفك القفل عن كل الأجهزة');
}
 
function setup_() {
  const ss = ss_();
  ss.setSpreadsheetTimeZone('Asia/Dubai');
  let tx = ss.getSheetByName(TX_SHEET);
  if (!tx) tx = ss.insertSheet(TX_SHEET);
  ensureCols_(tx, HEAD.length, HEAD);
  tx.setFrozenRows(1);
  tx.getRange('B:B').setNumberFormat('@');
  tx.setRightToLeft(true);
  let cfg = ss.getSheetByName(CFG_SHEET);
  if (!cfg) {
    cfg = ss.insertSheet(CFG_SHEET);
    cfg.getRange(1,1,2,2).setValues([['إرسال تلقائي','نعم'],['الإيميلات','']]);
    cfg.setRightToLeft(true);
  }
  Logger.log('تم التجهيز. الحركات: ' + (tx.getLastRow()-1));
}
 
function doGet(e) { return out_({ok:false,error:'post_required',detail:'استخدم POST فقط؛ لا ترسل بيانات الدخول في الرابط.'}); }
function doPost(e) {
  let p = {};
  try { if (!e || !e.postData || e.postData.contents.length > 70000) return out_({ok:false,error:'bad_request'}); p = JSON.parse(e.postData.contents); } catch (err) { return out_({ok:false, error:'bad_request'}); }
  return out_(handleRequest_(p));
}
function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
 
function handleRequest_(p) {
  BASE_ = null; CLOSINGS_ = null;
  const t0 = Date.now();
  try { const r = handle_(p); if (r && typeof r === 'object') r.ms = Date.now() - t0; return r; }
  catch (e) { Logger.log(String(e&&e.message||e)); return {ok:false, error:'server', detail:'تعذر تنفيذ العملية. راجع سجل الخادم.'}; }
}
 
function handle_(p) {
  if (!p || typeof p !== 'object' || Array.isArray(p)) return {ok:false,error:'bad_request'};
  if (p.action === 'login') return loginSession_(p);
  const session = getSession_(p.token);
  if (!session) return {ok:false,error:'session_expired'};
  const role = session.role, dev = session.id;
  if (p.action === 'logout') { PropertiesService.getScriptProperties().deleteProperty('session:' + hash_(p.token)); return {ok:true}; }
  const action = p.action || 'list';
  if (typeof action !== 'string') return {ok:false,error:'bad_request'};
  // متابعة الاستخدام: مين متصل الحين، وسجل الدخول والصفحات
  if (action === 'list' || action === 'track') {
    const who = whoOf_(p, role);
    try { touchPresence_(dev, who, role, p.page); } catch (e) {}
    try { logEvents_(dev, who, role, p.ev); } catch (e) {}
    if (action === 'track') return {ok:true};
    const res = listPayload_(role);
    if (role === 'admin') { try { res.online = onlineList_().length; } catch (e) {} }
    return res;
  }
  if (action === 'activity') { if (role !== 'admin') return {ok:false, error:'forbidden'}; return activityPayload_(); }
  if (role === 'view') return {ok:false, error:'forbidden'};
  if (action === 'wa') return {ok:false,error:'notification_requires_server_event',detail:'الإشعار الحر معطل؛ يلزم ربطه بحركة محفوظة في الخادم.'};                       // المدير أو الوكيل بعد اعتماد حركة
  if (action.indexOf('wa-') === 0) {                           // إعداد الواتساب: للمدير بس
    if (role !== 'admin') return {ok:false, error:'forbidden'};
    return waAdmin_(action, p);
  }
 
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(15000)) return {ok:false, error:'busy'};
  let res;
  try {
    res = act_(p, role, action);
    // بعد أي تعديل نجدد الذاكرة السريعة (بعد الكتابة، عشان ما تنحفظ بيانات ناقصة)
    if (action !== 'notify') bumpData_();
  } finally { lock.releaseLock(); }
  // للسرعة: بعد العمليات المهمة نرجّع البيانات المحدّثة في نفس الرد، بدل ما يطلبها التطبيق مرة ثانية
  if (res && res.ok && ['approve','reject','dismiss','cancel','propose','close','close-del','reopen','prop-put','prop-del'].indexOf(action) >= 0) {
    BASE_ = null; CLOSINGS_ = null; res.list = listPayload_(role);
  }
  return res;
}
function listPayload_(role) {
  const d = baseData_();
  const meta=builtinMeta_();delete meta.props;
  const res = {ok:true, v:6, meta, role, txs: d.txs, closings: d.closings, lock: d.lock, props: mergedProps_()};
  if (role === 'admin') res.cfg = d.cfg;
  if (role !== 'view') { res.reqs = d.reqs.filter(r => r.status !== 'dismissed' && r.status !== 'cancelled' && (r.by === role || r.status === 'pending')); res.agent = AGENT_NAME; }
  return res;
}
 
/* ===== ذاكرة سريعة: البيانات تنحفظ جاهزة، فالقراءة ما تفتح الشيت كل مرة =====
   أي تعديل من التطبيق يجدد النسخة فوراً. وأي تعديل يدوي في الشيت يبان خلال 5 دقايق
   (أو فوراً إذا شغّلت installEditTrigger مرة وحدة). */
const CACHE_TTL = 300;
let BASE_ = null;
function dataVer_() { return PropertiesService.getScriptProperties().getProperty('dataVer_') || '0'; }
function bumpData_() { PropertiesService.getScriptProperties().setProperty('dataVer_', Date.now().toString(36) + Math.random().toString(36).slice(2, 8)); BASE_ = null; CLOSINGS_ = null; }
function baseData_() {
  if (BASE_) return BASE_;
  const cache = CacheService.getScriptCache(), k = 'L:' + dataVer_();
  try {
    const n = +(cache.get(k + ':n') || 0);
    if (n > 0) {
      const keys = []; for (let i = 0; i < n; i++) keys.push(k + ':' + i);
      const got = cache.getAll(keys); let s = '';
      for (let i = 0; i < n; i++) { const part = got[keys[i]]; if (part == null) { s = null; break; } s += part; }
      if (s != null) return (BASE_ = JSON.parse(s));
    }
  } catch (e) {}
  const d = {txs: readAll_(), closings: readClosings_(), lock: lockDate_(), reqs: readReqs_(), cfg: readCfg_(), props: readProps_()};
  try {
    const s = JSON.stringify(d), parts = {}, size = 30000; let n = 0;
    for (let i = 0; i < s.length; i += size) parts[k + ':' + (n++)] = s.slice(i, i + size);
    parts[k + ':n'] = String(n);
    cache.putAll(parts, CACHE_TTL);
  } catch (e) {}
  return (BASE_ = d);
}
// اختياري: يخلي أي تعديل يدوي في الشيت يبان في التطبيق فوراً (شغّلها مرة وحدة من المحرر)
function installEditTrigger_() {
  ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'onSheetEdit').forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('onSheetEdit').forSpreadsheet(SHEET_ID).onEdit().create();
  ScriptApp.newTrigger('onSheetEdit').forSpreadsheet(SHEET_ID).onChange().create();
}
function onSheetEdit() { bumpData_(); }
// يحدّث الذاكرة يدوياً
function refreshNow_() { bumpData_(); Logger.log('تم'); }
function actCore_(p, role, action) {
  {
    if (action === 'propose') {
      if (['put','del','close'].indexOf(p.op) < 0) return {ok:false, error:'bad_request'};
      if (p.op === 'close') {               // الوكيل يجهّز الإقفال وينتظر اعتماد المدير
        if (role !== 'agent') return {ok:false, error:'forbidden'};
        const bad = badClosing_(p.tx); if (bad) return {ok:false, error:'bad_request', detail:bad};
        const rid = addReq_('close', p.tx, p.tx.id, role);
        notifyOwner_('close', p.tx);
        return {ok:true, id:rid};
      }
      if (p.op === 'put' && p.id && p.tx && p.id !== p.tx.id) return {ok:false,error:'bad_request',detail:'id_mismatch'};
      // المدير ما يرسل طلب إلا على حركة باسم الوكيل
      if (role === 'admin' && ownerOf_(p.id || (p.tx && p.tx.id)) !== 'agent') return {ok:false, error:'not_owned'};
      if (p.op === 'del') { if (!validId_(p.id) || findRow_(p.id) < 0) return {ok:false, error:'not_found'}; }
      else {
        const bad = badTx_(p.tx); if (bad) return {ok:false, error:'bad_request', detail:bad};
        // الوكيل ما يقدر يسوي حركة "سابقة" جديدة (تتخطى القفل وما تأثر على الرصيد)
        if (role === 'agent' && p.tx.hist && !isHistRow_(p.tx.id)) return {ok:false,error:'forbidden'};
      }
      if (lockedTx_(p.op === 'del' ? null : p.tx, p.op === 'del' ? p.id : p.tx.id)) return {ok:false, error:'closed'};
      const r = addReq_(p.op, p.tx, p.op === 'del' ? p.id : p.tx.id, role);
      if (role === 'agent') notifyOwner_(p.op, p.tx);
      return {ok:true, id:r};
    }
    if (action === 'approve' || action === 'reject') {
      const r = readReqs_().find(x => x.rid === p.rid);
      if (!r) return {ok:false, error:'not_found'};
      if (!['put','del','close'].includes(r.op) || (r.op !== 'del' && (!r.tx || r.id !== r.tx.id))) return {ok:false,error:'bad_request'};
      if (r.op === 'close' && role !== 'admin') return {ok:false,error:'forbidden'};
      if (r.by === role) return {ok:false, error:'forbidden'};          // ما يعتمد طلبه بنفسه
      if (r.status !== 'pending') return {ok:true, req:r, already:true}; // انعتمد أو انرفض قبل
      if (action === 'approve') {
        if (r.op === 'close') { const bad = badClosing_(r.tx); if (bad) return {ok:false, error:'bad_request', detail:bad}; saveClosing_(r.tx, r.by, role); }
        else if (r.op !== 'del' && badTx_(r.tx)) return {ok:false, error:'bad_request', detail:badTx_(r.tx)};
        else if (lockedTx_(r.op === 'del' ? null : r.tx, r.id)) return {ok:false, error:'closed'};
        else if (r.op === 'del') remove_(r.id);
        else {
          const prev = ownerOf_(r.tx.id);
          upsert_(r.tx, prev || (r.by === 'agent' ? 'agent' : ''));
        }
      }
      setReqStatus_(r.rid, action === 'approve' ? 'approved' : 'rejected');
      r.status = action === 'approve' ? 'approved' : 'rejected';
      return {ok:true, req:r};
    }
    if (action === 'dismiss') {        // الطالب يشيل طلبه (معلّق = إلغاء، أو بعد القرار)
      const r = readReqs_().find(x => x.rid === p.rid);
      if (r && r.by !== role) return {ok:false, error:'forbidden'};
      if (r) setReqStatus_(r.rid, r.status === 'pending' ? 'cancelled' : 'dismissed');
      return {ok:true};
    }
    if (action === 'cancel') { const r = readReqs_().find(x => x.rid === p.rid); if (r && r.by === role && r.status === 'pending') setReqStatus_(r.rid,'cancelled'); return {ok:true}; }
    if (action === 'notify') return {ok:false,error:'notification_requires_server_event'};
    if (role !== 'admin') return {ok:false, error:'forbidden'};
 
    if (action === 'close') {
      const bad = badClosing_(p.close); if (bad) return {ok:false, error:'bad_request', detail:bad};
      const c = saveClosing_(p.close, 'admin', 'admin'); return {ok:true, closing:c};
    }
    if (action === 'close-del') {         // حذف إقفال تجريبي
      const row = closeRow_(p.id); if (row < 0) return {ok:false, error:'not_found'};
      if (String(closeSheet_().getRange(row,4).getValue()) !== 'نعم') return {ok:false, error:'forbidden'};
      closeSheet_().deleteRow(row); CLOSINGS_ = null; return {ok:true};
    }
    if (action === 'reopen') {            // فتح سنة مقفولة (يلغي القفل ويبقى السجل)
      const row = closeRow_(p.id); if (row < 0) return {ok:false, error:'not_found'};
      if (String(closeSheet_().getRange(row,4).getValue()) === 'نعم') return {ok:false, error:'forbidden'};
      closeSheet_().getRange(row,15).setValue('أعيد فتحها ' + Utilities.formatDate(new Date(), 'Asia/Dubai', 'yyyy-MM-dd HH:mm')); CLOSINGS_ = null;
      return {ok:true};
    }
    if (action === 'put') {
      const bad = badTx_(p.tx); if (bad) return {ok:false, error:'bad_request', detail:bad};
      if (ownerOf_(p.tx.id) === 'agent') return {ok:false, error:'owned'};
      if (lockedTx_(p.tx, p.tx && p.tx.id)) return {ok:false, error:'closed'};
      upsert_(p.tx); return {ok:true};
    }
    if (action === 'del') {
      if (!validId_(p.id)) return {ok:false, error:'bad_request'};
      if (ownerOf_(p.id) === 'agent') return {ok:false, error:'owned'};
      if (lockedTx_(null, p.id)) return {ok:false, error:'closed'};
      remove_(p.id); return {ok:true};
    }
    if (action === 'cfg') { writeCfg_(p.cfg || {}); return {ok:true, cfg: readCfg_()}; }
    if (action === 'prop-put') {
      const bad = badProp_(p.prop); if (bad) return {ok:false, error:'bad_request', detail:bad};
      putProp_(p.prop); return {ok:true};
    }
    if (action === 'prop-del') {
      if (!validPid_(p.id)) return {ok:false, error:'bad_request'};
      // إذا عليه حركات مسجّلة ما ينحذف، ينخفي بس (عشان ما تضيع الحركات القديمة)
      const used = readAll_().some(t => t.prop === p.id);
      if (used || BUILTIN_PROPS.indexOf(p.id) >= 0) { putProp_(Object.assign({}, findProp_(p.id) || {id:p.id}, {hidden:true}), true); return {ok:true, hidden:true}; }
      const row = propRow_(p.id); if (row > 0) propSheet_().deleteRow(row);
      return {ok:true};
    }
    return {ok:false, error:'unknown_action'};
  }
}
 
function sheet_() { const sh = ss_().getSheetByName(TX_SHEET); ensureCols_(sh, HEAD.length, HEAD); return sh; }
function ownerOf_(id) {
  if (!id) return '';
  const row = findRow_(id);
  return row > 0 ? String(sheet_().getRange(row, OWNER_COL).getValue() || '') : '';
}
 
/* ===== الطلبات بين المدير والوكيل ===== */
function ensureCols_(sh, n, head) {
  const key = sh.getName(); if (CHECKED_[key]) return;
  if (sh.getMaxColumns() < n) sh.insertColumnsAfter(sh.getMaxColumns(), n - sh.getMaxColumns());
  const h = sh.getRange(1,1,1,n).getValues()[0];
  if (head.some((x,i) => h[i] !== '' && h[i] !== x)) throw new Error('schema_mismatch:' + key);
  if (head.some((x,i) => h[i] !== x)) sh.getRange(1,1,1,n).setValues([head]);
  CHECKED_[key] = true;
}
function reqSheet_() {
  const ss = ss_();
  let sh = ss.getSheetByName(REQ_SHEET);
  if (!sh) { sh = ss.insertSheet(REQ_SHEET); sh.setFrozenRows(1); sh.setRightToLeft(true); }
  ensureCols_(sh, REQ_HEAD.length, REQ_HEAD);
  return sh;
}
function readReqs_() {
  const sh = reqSheet_(), last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2,1,last-1,REQ_HEAD.length).getValues().filter(r => r[0] !== '').map(r => {
    let tx = null; try { tx = JSON.parse(String(r[3] || 'null')); } catch (e) {}
    return {rid:String(r[0]), op:String(r[1]), id:String(r[2]), tx, byName:String(r[4]), at:+r[5] || 0,
            by:String(r[6] || 'agent'), status:String(r[7] || 'pending'), decidedAt:+r[8] || 0};
  });
}
function addReq_(op, tx, id, by) {
  const sh = reqSheet_(), rid = 'r' + Date.now().toString(36) + Math.floor(Math.random()*1e4);
  const r = sh.getLastRow() + 1;
  sh.getRange(r,1,1,REQ_HEAD.length).setNumberFormat('@')
    .setValues([[rid, op === 'del' ? 'del' : op === 'close' ? 'close' : 'put', String(id || (tx && tx.id) || '').slice(0,40), JSON.stringify(tx || {}).slice(0,45000),
                 by === 'admin' ? 'المدير' : AGENT_NAME, String(Date.now()), by, 'pending', '']]);
  return rid;
}
function reqRow_(rid) {
  const sh = reqSheet_(), last = sh.getLastRow();
  if (last < 2) return -1;
  const ids = sh.getRange(2,1,last-1,1).getValues();
  for (let i = 0; i < ids.length; i++) if (String(ids[i][0]) === String(rid)) return i + 2;
  return -1;
}
function setReqStatus_(rid, status) {
  const row = reqRow_(rid);
  if (row > 0) reqSheet_().getRange(row,8,1,2).setNumberFormat('@').setValues([[status, String(Date.now())]]);
}
function delReq_(rid) {
  const row = reqRow_(rid);
  if (row > 0) reqSheet_().deleteRow(row);
}
function notifyOwner_(op, tx) {
  try {
    const what = op === 'del' ? 'حذف حركة' : op === 'close' ? 'إقفال سنة ' + (tx && tx.year) + (tx && tx.trial ? ' (تجريبي)' : '') : (KIND_AR[tx && tx.kind] || 'حركة') + ' بمبلغ ' + (tx ? tx.amount : '') + ' د.إ';
    MailApp.sendEmail({to: Session.getEffectiveUser().getEmail(), subject: 'وريث: طلب جديد بانتظار اعتمادك',
      body: AGENT_NAME + ' أرسل طلب: ' + what + '\nافتح تطبيق وريث للاعتماد أو الرفض.', name: 'تطبيق وريث'});
  } catch (e) {}
}
 
function readAll_() {
  const sh = sheet_(), ss = ss_(), tz = ss.getSpreadsheetTimeZone();
  const last = sh.getLastRow();
  if (last < 2) return [];
  const vals = sh.getRange(2,1,last-1,HEAD.length).getValues();
  return vals.filter(r => r[0] !== '' && r[PROP_COL] !== 'نعم').map(r => {
    let date = r[1];
    if (date instanceof Date) date = Utilities.formatDate(date, tz, "yyyy-MM-dd'T'HH:mm");
    else date = String(date).replace(' ', 'T').slice(0,16);
    const t = {
      id: String(r[0]), date, acct: ACCT_KEY[r[2]] || r[2], kind: KIND_KEY[r[3]] || r[3],
      amount: +r[4] || 0, from: String(r[5] || ''), note: String(r[6] || ''),
      createdAt: +r[8] || 0, updatedAt: +r[9] || 0
    };
    if (r[7] === 'نعم' || r[7] === true) t.hist = true;
    if (r[OWNER_COL-1]) t.owner = String(r[OWNER_COL-1]);
    if (r[PROP_COL-1] && validPid_(String(r[PROP_COL-1]))) t.prop = String(r[PROP_COL-1]);
    if (t.kind === 'dist') {
      t.alloc = {};
      HEIRS.forEach((h,i) => { const v = +r[10+i]; if (v > 0) t.alloc[h] = v; });
    }
    return t;
  });
}
 
function rowOf_(t, owner) {
  return [
    String(t.id), String(t.date || '').replace('T',' '), ACCT_AR[t.acct] || t.acct, KIND_AR[t.kind] || t.kind,
    +t.amount || 0, safeText_(t.from, 120), safeText_(t.note, 500), t.hist ? 'نعم' : '', createdAtOf_(t.id), revisionOf_(t.id)
  ].concat(HEIRS.map(h => t.kind === 'dist' && t.alloc && +t.alloc[h] > 0 ? +t.alloc[h] : '')).concat([owner || '', t.kind !== 'dist' && validPid_(t.prop) ? t.prop : '', '']);
}
 
function findRow_(id) {
  const sh = sheet_(), last = sh.getLastRow();
  if (last < 2) return -1;
  const ids = sh.getRange(2,1,last-1,1).getValues();
  for (let i = 0; i < ids.length; i++) if (String(ids[i][0]) === String(id)) return i + 2;
  return -1;
}
 
function upsert_(t, owner) {
  if (!t || !t.id) throw new Error('no id');
  const sh = sheet_(), row = findRow_(t.id);
  if (owner === undefined) owner = row > 0 ? String(sh.getRange(row, OWNER_COL).getValue() || '') : '';
  const vals = [rowOf_(t, owner)];
  if (row > 0) sh.getRange(row,1,1,HEAD.length).setValues(vals);
  else {
    const r = sh.getLastRow() + 1;
    sh.getRange(r,2).setNumberFormat('@');
    sh.getRange(r,1,1,HEAD.length).setValues(vals);
  }
  bumpData_();
}
 
function remove_(id) {
  const row = findRow_(id);
  if (row > 0) { sheet_().getRange(row, PROP_COL + 1).setValue('نعم'); sheet_().getRange(row,10).setValue(Date.now()); }
}
 
function readCfg_() {
  const sh = ss_().getSheetByName(CFG_SHEET);
  if (!sh) return {auto:false, emails:[], phones:{}, wa: waPublic_()};
  const v = sh.getRange(1,2,3,1).getValues();
  let phones = {};
  try { phones = cleanPhones_(JSON.parse(String(v[2][0] || '{}'))); } catch (e) { phones = {}; }
  return {
    auto: String(v[0][0]).trim() === 'نعم',
    emails: String(v[1][0] || '').split(/[\s,،;]+/).map(s => s.trim()).filter(Boolean),
    phones: phones,
    wa: waPublic_()
  };
}
 
// أرقام الواتساب: {معرّف الوارث: رقم بمفتاح الدولة بدون +}
function normPhone_(x) {
  let d = String(x == null ? '' : x).replace(/[٠-٩]/g, c => String(c.charCodeAt(0) - 1632)).replace(/\D/g, '');
  if (d.indexOf('00') === 0) d = d.slice(2);
  if (/^05\d{8}$/.test(d)) d = '971' + d.slice(1);
  return /^[1-9]\d{7,14}$/.test(d) ? d : '';
}
function cleanPhones_(o) {
  const out_ = {};
  if (!o || typeof o !== 'object' || Array.isArray(o)) return out_;
  Object.keys(o).slice(0, 40).forEach(k => {
    if (!/^[a-z]{2,16}$/.test(k)) return;
    const n = normPhone_(o[k]);
    if (n) out_[k] = n;
  });
  return out_;
}
 
function writeCfg_(c) {
  const sh = ss_().getSheetByName(CFG_SHEET);
  const cur = readCfg_();
  const auto = c.auto === undefined ? cur.auto : !!c.auto;
  const emails = Array.isArray(c.emails) ? c.emails : cur.emails;
  const ok = emails.map(e => String(e).trim().toLowerCase()).filter(e => /^[^\s@=+'"<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(e)).slice(0, 30);
  const phones = (c.phones && typeof c.phones === 'object') ? cleanPhones_(c.phones) : cur.phones;
  sh.getRange(1,1,3,2).setValues([
    ['إرسال تلقائي', auto ? 'نعم' : 'لا'],
    ['الإيميلات', ok.join(', ')],
    ['أرقام الواتساب', JSON.stringify(phones)]
  ]);
}
 
function notify_(subject, body) {
  const c = readCfg_();
  if (!c.auto || !c.emails.length) return {ok:true, sent:false};
  MailApp.sendEmail({
    to: Session.getEffectiveUser().getEmail(),
    bcc: c.emails.join(','),
    subject: String(subject || 'وريث').slice(0, 200),
    body: String(body || '').slice(0, 6000),
    name: 'تطبيق وريث'
  });
  return {ok:true, sent:true};
}
 
/* ===== الإقفال السنوي ===== */
function closeSheet_() {
  const ss = ss_();
  let sh = ss.getSheetByName(CLOSE_SHEET);
  if (!sh) { sh = ss.insertSheet(CLOSE_SHEET); sh.setFrozenRows(1); sh.setRightToLeft(true); }
  ensureCols_(sh, CLOSE_HEAD.length, CLOSE_HEAD);
  return sh;
}
function closeRow_(id) {
  const sh = closeSheet_(), last = sh.getLastRow();
  if (last < 2) return -1;
  const ids = sh.getRange(2,1,last-1,1).getValues();
  for (let i = 0; i < ids.length; i++) if (String(ids[i][0]) === String(id)) return i + 2;
  return -1;
}
function readClosings_() {
  if (CLOSINGS_) return CLOSINGS_;
  const sh = closeSheet_(), last = sh.getLastRow();
  if (last < 2) return (CLOSINGS_ = []);
  return CLOSINGS_ = sh.getRange(2,1,last-1,CLOSE_HEAD.length).getValues().filter(r => r[0] !== '').map(r => {
    let d = {}; try { d = JSON.parse(String(r[15] || '{}')); } catch (e) {}
    const st = String(r[14] || 'approved');
    return Object.assign(d, {id:String(r[0]), year:String(r[1]), date:String(r[2]).slice(0,10), trial:String(r[3]) === 'نعم',
      byName:String(r[10]), at:+r[11] || 0, approvedBy:String(r[12]), approvedAt:+r[13] || 0,
      status: st.indexOf('أعيد') === 0 ? 'reopened' : 'approved', statusText: st});
  });
}
// آخر تاريخ مقفول (إقفال فعلي معتمد، مو تجريبي ولا معاد فتحه)
function lockDate_() {
  return readClosings_().filter(c => !c.trial && c.status === 'approved').map(c => c.date).sort().pop() || '';
}
function txDate_(id) {
  if (!id) return '';
  const row = findRow_(id);
  if (row < 0) return '';
  const v = sheet_().getRange(row, 2).getValue();
  return v instanceof Date ? Utilities.formatDate(v, ss_().getSpreadsheetTimeZone(), 'yyyy-MM-dd') : String(v).slice(0,10);
}
// هل الحركة داخل سنة مقفولة؟ (الحركات السابقة الجديدة مسموحة لأنها ما تأثر على الرصيد)
function lockedTx_(tx, id) {
  const L = lockDate_(); if (!L) return false;
  const old = txDate_(id);
  if (old && old <= L) return true;
  if (tx && !old && tx.hist) return false;
  return !!(tx && String(tx.date || '').slice(0,10) && String(tx.date).slice(0,10) <= L);
}
function saveClosing_(c, by, approver) {
  if (!c || !c.year || !c.date) throw new Error('بيانات الإقفال ناقصة');
  c = serverClosing_(c);
  c.id = c.id || ('c' + Date.now().toString(36));
  const a = c.accts || {}, b = a.bld || {}, f = a.farm || {};
  const row = [c.id, String(c.year), String(c.date).slice(0,10), c.trial ? 'نعم' : 'لا', +b.close || 0, b.bank === '' || b.bank == null ? '' : +b.bank,
    +f.close || 0, f.bank === '' || f.bank == null ? '' : +f.bank, (+b.close || 0) + (+f.close || 0), safeText_(c.note, 500),
    by === 'admin' ? 'المدير' : AGENT_NAME, String(Date.now()), approver === 'admin' ? 'المدير' : AGENT_NAME, String(Date.now()), 'معتمد', JSON.stringify(c)];
  const sh = closeSheet_(), ex = closeRow_(c.id), r = ex > 0 ? ex : sh.getLastRow() + 1;
  sh.getRange(r,1,1,4).setNumberFormat('@');
  sh.getRange(r,1,1,CLOSE_HEAD.length).setValues([row]);
  CLOSINGS_ = null;
  return c;
}
 
/* ===== التحقق من البيانات قبل الحفظ ===== */
function validId_(id) { return typeof id === 'string' && /^[A-Za-z0-9_-]{1,40}$/.test(id); }
// أي نص يبدأ بـ = + - @ يتحول لمعادلة في الشيت، فنضيف قبله علامة '
function safeText_(s, max) { s = String(s == null ? '' : s).slice(0, max || 500); return /^[\s]*[=+\-@]/.test(s) ? "'" + s : s; }
function isHistRow_(id) { const row = findRow_(id); return row > 0 && String(sheet_().getRange(row, 8).getValue()) === 'نعم'; }
function badTx_(t) {
  if (!t || typeof t !== 'object') return 'no_tx';
  if (!validId_(t.id)) return 'id';
  if (['bld','farm','old'].indexOf(t.acct) < 0) return 'acct';
  if (['dep','exp','dist'].indexOf(t.kind) < 0) return 'kind';
  if (t.acct === 'old' && !(t.hist && t.kind === 'dist')) return 'acct';
  if (t.prop != null && t.prop !== '') {
    if (!validPid_(t.prop)) return 'prop';
    const prop = mergedProps_().find(x=>x.id===t.prop);
    if (!prop || prop.acct !== t.acct || prop.hidden) return 'prop';
  }
  if (!/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?$/.test(String(t.date || ''))) return 'date';
  const a = +t.amount; if (!moneyValid_(t.amount) || a <= 0) return 'amount';
  if (!realDate_(t.date)) return 'date';
  if (t.hist != null && typeof t.hist !== 'boolean') return 'hist';
  if (findRow_(t.id) > 0 && !!t.hist !== isHistRow_(t.id)) return 'hist_change';
  if (String(t.from || '').length > 120 || String(t.note || '').length > 500) return 'text_length';
  if (t.kind === 'dist') {
    if (!t.alloc || typeof t.alloc !== 'object' || Array.isArray(t.alloc)) return 'alloc';
    let s = 0; for (const k of Object.keys(t.alloc)) { if (HEIRS.indexOf(k) < 0) return 'alloc'; const v = +t.alloc[k]; if (!moneyValid_(t.alloc[k])) return 'alloc'; s += Math.round(v * 100); }
    if (s !== Math.round(a * 100)) return 'alloc_sum';
  }
  return '';
}
function badClosing_(c) {
  if (!c || typeof c !== 'object') return 'no_close';
  if (!validId_(c.id)) return 'id';
  if (!/^\d{4}$/.test(String(c.year))) return 'year';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(c.date)) || String(c.date).slice(0,4) !== String(c.year)) return 'date';
  if (!realDate_(c.date)) return 'date';
  if (c.trial != null && typeof c.trial !== 'boolean') return 'trial';
  if (closeRow_(c.id) > 0) return 'duplicate_close';
  if (!c.accts || typeof c.accts !== 'object') return 'accts';
  for (const key of ['bld','farm']) {
    const a = c.accts[key];
    if (!a || !moneyValid_(a.close, true)) return 'balance';
    if (a.bank != null && a.bank !== '' && !moneyValid_(a.bank, true)) return 'bank';
  }
  const today = Utilities.formatDate(new Date(), 'Asia/Dubai', 'yyyy-MM-dd');
  if (String(c.date) > today) return 'future';
  if (!c.trial) { const L = lockDate_(); if (L && String(c.date) <= L) return 'already_closed'; }
  return '';
}
 
/* ===== متابعة الاستخدام ===== */
const LOG_SHEET = 'سجل الدخول';
const LOG_HEAD = ['الوقت','الشخص','النوع','الجهاز','الحدث','الصفحة'];
const ROLE_AR = {admin:'مدير', agent:'وكيل', view:'وارث'};
const EV_AR = {login:'دخول', open:'فتح التطبيق', logout:'خروج', view:'تصفح', who:'اختار اسمه'};
const ONLINE_MS = 90 * 1000;   // يعتبر متصل إذا التطبيق كلّم الخادم خلال آخر دقيقة ونص
function whoOf_(p, role) {
  if (role === 'admin') return 'المدير';
  if (role === 'agent') return AGENT_NAME;
  const w = String(p.who || '');
  return HEIR_NAMES.indexOf(w) >= 0 ? w : 'وارث (بدون اسم)';
}
function presenceMap_() { try { return JSON.parse(CacheService.getScriptCache().get('presence') || '{}'); } catch (e) { return {}; } }
function touchPresence_(dev, who, role, page) {
  const m = presenceMap_(), now = Date.now();
  Object.keys(m).forEach(k => { if (now - m[k].at > 6 * 3600 * 1000) delete m[k]; });
  const old = m[dev];
  m[dev] = {who, role, page: String(page || '').slice(0, 40), at: now, since: old && now - old.at < ONLINE_MS ? old.since : now};
  CacheService.getScriptCache().put('presence', JSON.stringify(m), 21600);
}
function onlineList_() {
  const m = presenceMap_(), now = Date.now();
  return Object.keys(m).filter(k => now - m[k].at < ONLINE_MS).map(k => Object.assign({dev: k.slice(0, 6)}, m[k]));
}
function logSheet_() {
  const ss = ss_();
  let sh = ss.getSheetByName(LOG_SHEET);
  if (!sh) { sh = ss.insertSheet(LOG_SHEET); sh.setFrozenRows(1); sh.setRightToLeft(true); }
  ensureCols_(sh, LOG_HEAD.length, LOG_HEAD);
  return sh;
}
function logEvents_(dev, who, role, ev) {
  if (!Array.isArray(ev) || !ev.length) return;
  const rows = ev.slice(0, 25).map(x => [
    Utilities.formatDate(new Date(+x.at || Date.now()), 'Asia/Dubai', 'yyyy-MM-dd HH:mm:ss'),
    who, ROLE_AR[role] || role, String(dev).slice(0, 10), EV_AR[x && x.e] || 'تصفح', safeText_(x && x.p || '', 40)]);
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(4000)) return;
  try {
    const sh = logSheet_(), r = sh.getLastRow() + 1;
    sh.getRange(r, 1, rows.length, LOG_HEAD.length).setNumberFormat('@').setValues(rows);
  } finally { lock.releaseLock(); }
}
function activityPayload_() {
  const sh = logSheet_(), last = sh.getLastRow(), n = Math.min(600, Math.max(0, last - 1));
  const rows = n ? sh.getRange(last - n + 1, 1, n, LOG_HEAD.length).getValues() : [];
  return {ok:true, now: Date.now(), online: onlineList_(),
    log: rows.reverse().map(r => ({t: String(r[0]), who: String(r[1]), role: String(r[2]), dev: String(r[3]), e: String(r[4]), p: String(r[5])}))};
}
 
 
/* =====================================================================
 * الواتساب التلقائي (WhatsApp Cloud API من ميتا)
 * المفتاح ورقم الهاتف يتحفظون في خصائص السكربت (Script Properties)،
 * وما يرجعون للتطبيق أبداً. التطبيق يشوف بس: مربوط أو لا، وحالة القالب.
 * ===================================================================== */
const WA_API = 'https://graph.facebook.com/v23.0/';
const WA_TPL_BASE = 'wareeth_move';
const WA_LANG = 'ar';
const WA_LOG_SHEET = 'سجل الواتساب';
const WA_APP_URL = 'https://alqasaili-wareeth.github.io/wareeth/';
const WA_BODY = 'السلام عليكم {{1}}،\n' +
  'هذا إشعار من تطبيق وريث عن حركة في حسابات تركة مبارك علي القصيلي.\n\n' +
  'العملية: {{2}}\n' +
  'المبلغ: {{3}} درهم\n' +
  'التفاصيل: {{4}}\n' +
  'التاريخ: {{5}}\n\n' +
  'الرصيد المتاح الآن:\n' +
  'البناية: {{6}} درهم\n' +
  'المزارع: {{7}} درهم\n\n' +
  'هذه رسالة تلقائية، لا تحتاج رد.';
const WA_EXAMPLE = ['سعيد', 'إيداع جديد في حساب البناية', '12,500.00', 'من: إيجار شقة 3', '7 أكتوبر 2026 في 10:30 ص', '354,136.49', '120,000.00'];
 
function waProps_() { return PropertiesService.getScriptProperties(); }
function waConf_() {
  const P = waProps_();
  const g = k => P.getProperty(k) || '';
  return {token: g('wa_token'), phoneId: g('wa_phone_id'), waba: g('wa_waba'), tplName: g('wa_tpl_name') || WA_TPL_BASE,
          tpl: g('wa_tpl_status'), reason: g('wa_tpl_reason'), display: g('wa_display'), name: g('wa_name'), auto: g('wa_auto') === '1'};
}
function waPublic_() {
  try {
    const w = waConf_();
    return {ready: !!(w.token && w.phoneId), auto: w.auto, tpl: w.tpl, reason: w.reason, phone: w.display, name: w.name, tplName: w.tplName, hasWaba: !!w.waba};
  } catch (e) { return {ready:false}; }
}
// قيمة داخل القالب: ميتا ما تقبل أسطر جديدة ولا مسافات كثيرة ولا قيمة فاضية
function waTxt_(x, max) {
  let t = String(x == null ? '' : x).replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').replace(/[{}]/g, '').trim();
  t = t.slice(0, max || 250);
  return t || '—';
}
function waFetch_(w, path, method, body) {
  const o = {method: method || 'get', muteHttpExceptions: true, headers: {Authorization: 'Bearer ' + w.token}};
  if (body) { o.contentType = 'application/json'; o.payload = JSON.stringify(body); }
  const r = UrlFetchApp.fetch(WA_API + path, o);
  let j = {}; try { j = JSON.parse(r.getContentText()); } catch (e) {}
  return {code: r.getResponseCode(), j: j};
}
// شرح الأخطاء الشائعة بالعربي
function waErrAr_(err) {
  const e = err || {}, c = +e.code || 0, d = (e.error_data && e.error_data.details) || e.message || '';
  if (c === 190) return 'مفتاح الدخول (Token) منتهي أو غلط. سوّ مفتاح دائم من "مستخدم النظام" وحطه من جديد.';
  if (c === 10 || c === 200 || c === 3) return 'المفتاح ما عنده صلاحية واتساب. لازم يكون فيه whatsapp_business_messaging و whatsapp_business_management.';
  if (c === 100 && /phone|Unsupported get request|does not exist/i.test(d)) return 'رقم الهاتف (Phone number ID) أو رقم الحساب (WABA ID) غلط.';
  if (c === 131030) return 'هذا الرقم مو مضاف في قائمة الأرقام المسموحة لرقم التجربة. استخدم رقمك الحقيقي، أو أضف الرقم في صفحة API Setup.';
  if (c === 131026) return 'الرسالة ما وصلت: الرقم ما عليه واتساب أو ما قبل الشروط.';
  if (c === 131042) return 'فيه مشكلة في الدفع: أضف وسيلة دفع في WhatsApp Manager.';
  if (c === 131056 || c === 130429) return 'إرسال كثير بوقت قصير. حاول بعد شوي.';
  if (c === 132001) return 'القالب مو موجود أو للحين ما انعتمد.';
  if (c === 132000 || c === 132012) return 'بيانات القالب ما تطابق القالب المعتمد.';
  if (c === 133010) return 'رقم الهاتف مو مسجّل في الواتساب للأعمال. كمّل تسجيله في WhatsApp Manager.';
  if (c === 368 || c === 131031) return 'حساب الواتساب للأعمال موقوف أو مقيّد. راجع WhatsApp Manager.';
  return 'خطأ من ميتا' + (c ? ' (' + c + ')' : '') + (d ? ': ' + String(d).slice(0, 160) : '');
}
function waSaveTpl_(t) {
  const P = waProps_();
  P.setProperty('wa_tpl_status', t ? String(t.status || '') : '');
  P.setProperty('wa_tpl_reason', t && t.rejected_reason && t.rejected_reason !== 'NONE' ? String(t.rejected_reason) : '');
}
// يتأكد إن القالب موجود عند ميتا، وإذا مو موجود يطلبه
function waEnsureTemplate_(w) {
  if (!w.waba) return {ok:false, detail:'رقم حساب الواتساب للأعمال (WABA ID) ناقص.'};
  const q = waFetch_(w, w.waba + '/message_templates?fields=name,status,language,rejected_reason&limit=50&name=' + encodeURIComponent(w.tplName));
  if (q.code !== 200) return {ok:false, detail: waErrAr_(q.j.error)};
  const found = (q.j.data || []).filter(t => t.name === w.tplName && t.language === WA_LANG)[0];
  if (found) { waSaveTpl_(found); return {ok:true, status: found.status}; }
  const c = waFetch_(w, w.waba + '/message_templates', 'post', {
    name: w.tplName, language: WA_LANG, category: 'UTILITY',
    components: [
      {type:'BODY', text: WA_BODY, example: {body_text: [WA_EXAMPLE]}},
      {type:'FOOTER', text:'تطبيق وريث'},
      {type:'BUTTONS', buttons: [{type:'URL', text:'فتح التطبيق', url: WA_APP_URL}]}
    ]
  });
  if (c.code !== 200) return {ok:false, detail: waErrAr_(c.j.error)};
  waSaveTpl_({status: c.j.status || 'PENDING'});
  return {ok:true, status: c.j.status || 'PENDING'};
}
function waTemplateMsg_(w, to, params) {
  return {
    url: WA_API + w.phoneId + '/messages', method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: {Authorization: 'Bearer ' + w.token},
    payload: JSON.stringify({
      messaging_product: 'whatsapp', recipient_type: 'individual', to: to, type: 'template',
      template: {name: w.tplName, language: {code: WA_LANG},
        components: [{type:'body', parameters: params.map(t => ({type:'text', text: t}))}]}
    })
  };
}
function waLog_(rows) {
  try {
    const ss = ss_();
    let sh = ss.getSheetByName(WA_LOG_SHEET);
    if (!sh) { sh = ss.insertSheet(WA_LOG_SHEET); sh.appendRow(['الوقت','الوارث','الرقم','العملية','الحالة','التفاصيل']); sh.setFrozenRows(1); sh.setRightToLeft(true); }
    if (rows.length) sh.getRange(sh.getLastRow() + 1, 1, rows.length, 6).setValues(rows);
  } catch (e) {}
}
// حد للإرسال: 40 دفعة بالساعة (حماية من أي تكرار بالغلط)
function waRateOk_() {
  const c = CacheService.getScriptCache(), k = 'wa:n:' + Utilities.formatDate(new Date(), 'Asia/Dubai', 'yyyyMMddHH');
  const n = +(c.get(k) || 0);
  if (n >= 40) return false;
  c.put(k, String(n + 1), 3700);
  return true;
}
function waSend_(p) {
  const w = waConf_();
  if (!w.token || !w.phoneId || !w.auto || w.tpl !== 'APPROVED') return {ok:true, off:true, sent:0, failed:[]};
  const phones = readCfg_().phones, ids = HEIRS.filter(h => phones[h]);
  if (!ids.length) return {ok:true, sent:0, failed:[], none:true};
  if (!waRateOk_()) return {ok:false, error:'busy'};
  const P = (p.wa && typeof p.wa === 'object') ? p.wa : {};
  const what = waTxt_(P.what, 120), amount = waTxt_(P.amount, 40), detail = waTxt_(P.detail, 200), date = waTxt_(P.date, 60);
  const bld = waTxt_(P.bld, 40), farm = waTxt_(P.farm, 40);
  const alloc = (P.alloc && typeof P.alloc === 'object' && !Array.isArray(P.alloc)) ? P.alloc : {};
  const reqs = ids.map(id => {
    const share = alloc[id] != null ? waTxt_(alloc[id], 40) : '';
    const det = share && share !== '—' ? waTxt_(detail + ' · نصيبك: ' + share + ' درهم', 250) : detail;
    return waTemplateMsg_(w, phones[id], [HEIR_NAMES[HEIRS.indexOf(id)], what, amount, det, date, bld, farm]);
  });
  let resps;
  try { resps = UrlFetchApp.fetchAll(reqs); }
  catch (e) { return {ok:false, error:'wa', detail:'ما قدر الخادم يوصل لواتساب: ' + String(e && e.message || e).slice(0, 120)}; }
  const now = Utilities.formatDate(new Date(), 'Asia/Dubai', 'yyyy-MM-dd HH:mm'), failed = [], log = [];
  let sent = 0;
  resps.forEach((r, i) => {
    const id = ids[i], name = HEIR_NAMES[HEIRS.indexOf(id)];
    let j = {}; try { j = JSON.parse(r.getContentText()); } catch (e) {}
    if (r.getResponseCode() === 200 && j.messages && j.messages[0]) { sent++; log.push([now, name, "'+" + phones[id], what, 'انرسلت', j.messages[0].id]); }
    else { const why = waErrAr_(j.error); failed.push({id: id, why: why}); log.push([now, name, "'+" + phones[id], what, 'ما انرسلت', why]); }
  });
  waLog_(log);
  // لو القالب انوقف أو انحذف عند ميتا، نحدّث حالته عشان التطبيق يرجع للإرسال اليدوي
  if (failed.length === ids.length && /القالب/.test(failed[0].why)) { try { waEnsureTemplate_(w); bumpData_(); } catch (e) {} }
  return {ok:true, sent: sent, failed: failed};
}
function waAdmin_(action, p) {
  const P = waProps_();
  if (action === 'wa-setup') {
    const token = String(p.token || '').trim(), phoneId = String(p.phoneId || '').replace(/\D/g, ''), waba = String(p.waba || '').replace(/\D/g, '');
    if (!/^[A-Za-z0-9_\-.|]{40,1200}$/.test(token)) return {ok:false, error:'wa', detail:'مفتاح الدخول (Token) شكله مو صحيح. انسخه كامل.'};
    if (!/^\d{6,25}$/.test(phoneId)) return {ok:false, error:'wa', detail:'Phone number ID لازم يكون أرقام بس.'};
    if (!/^\d{6,25}$/.test(waba)) return {ok:false, error:'wa', detail:'WABA ID لازم يكون أرقام بس.'};
    const w = {token: token, phoneId: phoneId, waba: waba, tplName: waConf_().tplName};
    const r = waFetch_(w, phoneId + '?fields=display_phone_number,verified_name');
    if (r.code !== 200) return {ok:false, error:'wa', detail: waErrAr_(r.j.error)};
    P.setProperties({wa_token: token, wa_phone_id: phoneId, wa_waba: waba,
      wa_display: String(r.j.display_phone_number || ''), wa_name: String(r.j.verified_name || '')});
    const t = waEnsureTemplate_(w);
    bumpData_();
    return {ok:true, cfg: readCfg_(), tplErr: t.ok ? '' : t.detail};
  }
  const w = waConf_();
  if (action === 'wa-off') {
    ['wa_token','wa_phone_id','wa_waba','wa_display','wa_name','wa_tpl_status','wa_tpl_reason','wa_auto'].forEach(k => P.deleteProperty(k));
    bumpData_(); return {ok:true, cfg: readCfg_()};
  }
  if (!w.token || !w.phoneId) return {ok:false, error:'wa', detail:'الواتساب مو مربوط للحين.'};
  if (action === 'wa-status') {
    const t = waEnsureTemplate_(w); bumpData_();
    return t.ok ? {ok:true, cfg: readCfg_()} : {ok:false, error:'wa', detail: t.detail};
  }
  if (action === 'wa-retpl') {          // القالب انرفض: نطلب قالب جديد باسم ثاني
    const m = w.tplName.match(/_(\d+)$/), next = WA_TPL_BASE + '_' + ((m ? +m[1] : 1) + 1);
    P.setProperty('wa_tpl_name', next); waSaveTpl_(null);
    const t = waEnsureTemplate_(waConf_()); bumpData_();
    return t.ok ? {ok:true, cfg: readCfg_()} : {ok:false, error:'wa', detail: t.detail};
  }
  if (action === 'wa-auto') { P.setProperty('wa_auto', p.on ? '1' : '0'); bumpData_(); return {ok:true, cfg: readCfg_()}; }
  if (action === 'wa-test') {
    if (!waRateOk_()) return {ok:false,error:'busy'};
    const to = normPhone_(p.to);
    if (!to) return {ok:false, error:'wa', detail:'اكتب رقم صحيح للتجربة.'};
    let msg;
    if (w.tpl === 'APPROVED') {
      msg = waTemplateMsg_(w, to, ['(تجربة)', 'رسالة تجربة من تطبيق وريث', '0.00', 'هذي رسالة تجربة، ما فيه حركة حقيقية', Utilities.formatDate(new Date(), 'Asia/Dubai', 'yyyy-MM-dd HH:mm'), '—', '—']);
    } else {   // قبل ما ينعتمد قالبنا: نجرب بقالب ميتا الجاهز hello_world
      msg = {url: WA_API + w.phoneId + '/messages', method:'post', contentType:'application/json', muteHttpExceptions:true,
        headers:{Authorization:'Bearer ' + w.token},
        payload: JSON.stringify({messaging_product:'whatsapp', to: to, type:'template', template:{name:'hello_world', language:{code:'en_US'}}})};
    }
    const r = UrlFetchApp.fetchAll([msg])[0];
    let j = {}; try { j = JSON.parse(r.getContentText()); } catch (e) {}
    const ok = r.getResponseCode() === 200 && j.messages;
    waLog_([[Utilities.formatDate(new Date(), 'Asia/Dubai', 'yyyy-MM-dd HH:mm'), 'تجربة', "'+" + to, 'رسالة تجربة', ok ? 'انرسلت' : 'ما انرسلت', ok ? j.messages[0].id : waErrAr_(j.error)]]);
    return ok ? {ok:true, kind: w.tpl === 'APPROVED' ? 'ours' : 'hello'} : {ok:false, error:'wa', detail: waErrAr_(j.error)};
  }
  return {ok:false, error:'bad_request'};
}
// شغّل هذي الدالة مرة وحدة من المحرر بعد لصق الكود، عشان توافق على صلاحية "الاتصال بخدمة خارجية"
function waCheck_() {
  const w = waConf_();
  if (!w.token) { UrlFetchApp.fetch('https://graph.facebook.com/', {muteHttpExceptions:true}); Logger.log('تمت الموافقة على الصلاحيات. الواتساب للحين مو مربوط: اربطه من إعدادات التطبيق.'); return; }
  const r = waFetch_(w, w.phoneId + '?fields=display_phone_number,verified_name,quality_rating');
  Logger.log(r.code === 200 ? 'مربوط برقم ' + r.j.display_phone_number + ' (' + r.j.verified_name + ')، حالة القالب: ' + (w.tpl || '—') : waErrAr_(r.j.error));
}
 
/* ===== العقارات ===== */
const BUILTIN_PROPS = ['bld','jrm','yaw','ghy'];   // العقارات الأصلية المكتوبة في التطبيق
function validPid_(id) { return typeof id === 'string' && /^[a-z0-9_-]{1,24}$/.test(id); }
function propSheet_() {
  const ss = ss_();
  let sh = ss.getSheetByName(PROP_SHEET);
  if (!sh) { sh = ss.insertSheet(PROP_SHEET); sh.setFrozenRows(1); sh.setRightToLeft(true); }
  ensureCols_(sh, PROP_HEAD.length, PROP_HEAD);
  return sh;
}
function readProps_() {
  const sh = ss_().getSheetByName(PROP_SHEET);
  if (!sh || sh.getLastRow() < 2) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, PROP_HEAD.length).getValues().filter(r => validPid_(String(r[0]))).map(r => {
    let shares = null;
    try { const s = JSON.parse(String(r[10] || 'null')); if (s && typeof s === 'object') shares = cleanShares_(s); } catch (e) {}
    const o = {id: String(r[0]), name: String(r[1] || ''), acct: ACCT_KEY[r[2]] || String(r[2] || ''), plot: String(r[3] || ''), where: String(r[4] || ''),
      area: +r[5] || 0, use: String(r[6] || ''), addr: String(r[7] || ''), date: String(r[8] || ''), src: String(r[9] || ''), shares};
    if (r[11] === 'نعم' || r[11] === true) o.hidden = true;
    return o;
  });
}
function findProp_(id) { return mergedProps_().find(x => x.id === id); }
function propRow_(id) {
  const sh = propSheet_(), last = sh.getLastRow();
  if (last < 2) return -1;
  const ids = sh.getRange(2, 1, last - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) if (String(ids[i][0]) === id) return i + 2;
  return -1;
}
function cleanShares_(s) {
  const out_ = {}; let n = 0;
  HEIRS.forEach(h => { const v = +s[h]; if (isFinite(v) && v >= 0 && v <= 100) { out_[h] = Math.round(v * 10000) / 10000; n++; } });
  return n ? out_ : null;
}
function badProp_(p) {
  if (!p || typeof p !== 'object') return 'no_prop';
  if (!validPid_(p.id)) return 'id';
  if (!String(p.name || '').trim() || String(p.name).length > 80) return 'name';
  if (['bld','farm'].indexOf(p.acct) < 0) return 'acct';
  if (p.area != null && p.area !== '' && !(isFinite(+p.area) && +p.area >= 0 && +p.area < 1e9)) return 'area';
  if (p.shares) {
    const s = cleanShares_(p.shares); if (!s) return 'shares';
    const sum = HEIRS.reduce((a, h) => a + (+s[h] || 0), 0);
    if (Math.abs(sum - 100) > 0.05) return 'shares_sum';
  }
  return '';
}
function putProp_(p, keepHidden) {
  const sh = propSheet_(), row = propRow_(p.id);
  const created = row > 0 ? +sh.getRange(row, 13).getValue() || Date.now() : Date.now();
  const vals = [[p.id, safeText_(p.name, 80), ACCT_AR[p.acct] || p.acct, safeText_(p.plot, 40), safeText_(p.where, 120),
    p.area === '' || p.area == null ? '' : +p.area, safeText_(p.use, 120), safeText_(p.addr, 60), safeText_(p.date, 20), safeText_(p.src, 120),
    p.shares ? JSON.stringify(cleanShares_(p.shares)) : '', p.hidden ? 'نعم' : '', created, Date.now()]];
  if (row > 0) sh.getRange(row, 1, 1, PROP_HEAD.length).setValues(vals);
  else sh.getRange(sh.getLastRow() + 1, 1, 1, PROP_HEAD.length).setValues(vals);
}
 
// Helpers added by the reviewed candidate.
function moneyValid_(v, signed) {
  if ((typeof v !== 'number' && typeof v !== 'string') || v === '' || String(v).trim() === '') return false;
  const n = Number(v);
  return Number.isFinite(n) && Math.abs(n) <= 1e9 && (signed || n >= 0) && Math.abs(n * 100 - Math.round(n * 100)) < 0.0001;
}
function realDate_(v) {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/.exec(String(v));
  if (!m || +m[1] < 1900 || (m[4] != null && (+m[4] > 23 || +m[5] > 59))) return false;
  const d = new Date(Date.UTC(+m[1], +m[2]-1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2]-1 && d.getUTCDate() === +m[3];
}
function createdAtOf_(id) {
  const row = findRow_(id);
  return row > 0 ? Number(sheet_().getRange(row, 9).getValue()) || Date.now() : Date.now();
}
function builtinMeta_(){
const HEIRS=[
  {id:'may',n:'مي',full:'مي راشد راشد المنصوري'},
  {id:'rashed',n:'راشد',full:'راشد مبارك علي القصيلي المنصوري'},
  {id:'saeed',n:'سعيد',full:'سعيد مبارك علي القصيلي المنصوري'},
  {id:'ali',n:'علي',full:'علي مبارك علي القصيلي المنصوري'},
  {id:'eid',n:'عيد',full:'عيد مبارك علي محمد المنصوري'},
  {id:'mohamed',n:'محمد',full:'محمد مبارك علي محمد المنصوري'},
  {id:'naser',n:'ناصر',full:'ناصر مبارك علي القصيلي المنصوري'},
  {id:'bakheeta',n:'بخيتة',full:'بخيتة مبارك علي المنصوري'},
  {id:'hamda',n:'حمدة',full:'حمدة مبارك علي القصيلي المنصوري'},
  {id:'shamma',n:'شمة',full:'شمة مبارك علي المنصوري'},
  {id:'madhheya',n:'مضحية',full:'مضحية مبارك علي المنصوري'},
  {id:'noura',n:'نورة',full:'نورة مبارك علي المنصوري'}
];
const H=Object.fromEntries(HEIRS.map(h=>[h.id,h]));
const SONS=['rashed','saeed','ali','eid','mohamed','naser'], DAUS=['bakheeta','hamda','shamma','madhheya','noura'];
function mk(may,son,dau){const o={may};SONS.forEach(s=>o[s]=son);DAUS.forEach(d=>o[d]=dau);return o;}
const ACCTS={
  bld:{name:'حساب البناية',short:'البناية',shares:Object.assign(mk(1.0416,9.1912,8.7622),{naser:9.1911,saeed:9.1911,eid:9.1911})},
  farm:{name:'حساب المزارع',short:'المزارع',shares:mk(12.5,10.2941,5.147)},
  old:{name:'توزيعات قبل التطبيق',short:'سابق',shares:mk(12.5,10.2941,5.147)}
};
// الكسور الدقيقة اللي تطلع منها نسب السندات (النسب المكتوبة مقرّبة لأربع خانات)
// الإرث: الزوجة 1/8، كل ابن 7/68، كل بنت 7/136. البناية: منحة 1/12 لكل ابن وبنت + إرث الـ 1/12 الباقي بنفس الأنصبة.
function frac(may,son,dau){const o={may};SONS.forEach(s=>o[s]=son);DAUS.forEach(d=>o[d]=dau);return o;}
const W={bld:frac(1/96,1/12+7/816,1/12+7/1632),farm:frac(1/8,7/68,7/136)};W.old=W.farm;
const PROPS=[
  {id:'bld',acct:'bld',name:'البناية',plot:'C44',where:'مدينة محمد بن زايد (ME12)، أبوظبي',area:325.16,use:'تجاري – أبراج سكنية R35',addr:'6-283-000-C44',date:'1994/05/02',src:'مخطط أرض – مركز أبوظبي العقاري',shares:ACCTS.bld.shares},
  {id:'jrm',acct:'farm',name:'مزرعة جريمدة',plot:'FRM8',where:'ليوا، منطقة الظفرة',area:7228.42,use:'زراعي – أرض زراعية',addr:'25-5-000-FRM8',date:'2007/03/06',src:'مخطط أرض – دائرة البلديات والنقل',shares:Object.assign(mk(12.5,10.2941,5.147),{shamma:5.1469,noura:5.1469})},
  {id:'yaw',acct:'farm',name:'مزرعة يو النظرة',plot:'FRM41',where:'يو النظرة، منطقة الظفرة',area:40000,use:'زراعي – أرض زراعية · غير مرهون',addr:'0-3-000-FRM41',date:'2007/03/18',src:'سند ملكية – مركز أبوظبي العقاري',shares:mk(12.5,10.2941,5.147)},
  {id:'ghy',acct:'farm',name:'المسكن الشعبي – غياثي',plot:'300',where:'غياثي، منطقة الظفرة',area:5063,use:'سكني – بيت شعبي',addr:'27-9-000-300',date:'2007/03/25',src:'مخطط أرض – دائرة البلديات والنقل',shares:Object.assign(mk(12.5007,10.2941,5.1469))}
];

return {heirs:HEIRS,props:PROPS};
}

/* ===== v6: sessions, durable operation journal, audit, queued notifications ===== */
const SESSION_MS_ = 30 * 60 * 1000;
function hash_(s) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(s)).map(b=>(b<0?b+256:b).toString(16).padStart(2,'0')).join(''); }
function pins_() { return [String(ADMIN_PIN),String(VIEW_PIN),String(AGENT_PIN)]; }
function loginSession_(p) {
  const pins=pins_();
  if(pins.some(x=>!/^\d{6,12}$/.test(x))||new Set(pins).size!==3)return {ok:false,error:'setup'};
  const lock=LockService.getScriptLock();if(!lock.tryLock(5000))return {ok:false,error:'busy'};
  try {
    const pr=PropertiesService.getScriptProperties(),now=Date.now();
    let attempts={n:0,until:now+LOCK_SECONDS*1000};try{attempts=JSON.parse(pr.getProperty('loginAttempts')||'null')||attempts;}catch(e){}
    if(attempts.until<=now)attempts={n:0,until:now+LOCK_SECONDS*1000};
    if(attempts.n>=30)return {ok:false,error:'locked',retryAfter:Math.ceil((attempts.until-now)/1000)};
    const pin=typeof p.pin==='string'?p.pin:'', i=pins.indexOf(pin);
    if(i<0){attempts.n++;pr.setProperty('loginAttempts',JSON.stringify(attempts));return {ok:false,error:'pin'};}
    // Invalid attempts are global and durable; changing dev cannot reset the budget.
    const all=pr.getProperties();Object.keys(all).filter(k=>k.startsWith('session:')).forEach(k=>{try{if(JSON.parse(all[k]).expires<=now)pr.deleteProperty(k);}catch(e){pr.deleteProperty(k);}});
    const active=Object.keys(pr.getProperties()).filter(k=>k.startsWith('session:'));if(active.length>=80)return {ok:false,error:'busy'};
    const token=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,''),role=['admin','view','agent'][i];
    pr.setProperty('session:'+hash_(token),JSON.stringify({role,expires:now+SESSION_MS_,id:Utilities.getUuid().replace(/-/g,''),pinHash:hash_(pin)}));
    return {ok:true,token,role,expires:now+SESSION_MS_,v:6};
  } finally {lock.releaseLock();}
}
function getSession_(token) {
  if(typeof token!=='string'||!/^[a-f0-9]{64}$/.test(token))return null;
  const pr=PropertiesService.getScriptProperties(),key='session:'+hash_(token);let s;
  try{s=JSON.parse(pr.getProperty(key)||'null');}catch(e){return null;}
  if(!s||s.expires<=Date.now()) {pr.deleteProperty(key);return null;}
  const i={admin:0,view:1,agent:2}[s.role];if(i==null||s.pinHash!==hash_(pins_()[i])){pr.deleteProperty(key);return null;}
  return s;
}
function revokeSessions_() { const pr=PropertiesService.getScriptProperties();Object.keys(pr.getProperties()).filter(k=>k.startsWith('session:')).forEach(k=>pr.deleteProperty(k)); }
function mergedProps_(){const m={};builtinMeta_().props.forEach(p=>m[p.id]=p);readProps_().forEach(p=>m[p.id]=Object.assign({},m[p.id]||{},p));return Object.values(m);}
function currentTx_(id){return readAll_().find(t=>t.id===id)||null;}
function sameTx_(a,b){if(!a||!b)return false;const keys=['id','date','acct','kind','amount','from','note','hist','prop'];return keys.every(k=>String(a[k]??'')===String(b[k]??''))&&JSON.stringify(a.alloc||{})===JSON.stringify(b.alloc||{});}
function assertVersion_(id,version){const t=currentTx_(id);return (t?Number(t.updatedAt):0)===Number(version);}
function table_(name,head){let sh=ss_().getSheetByName(name);if(!sh){sh=ss_().insertSheet(name);sh.setRightToLeft(true);sh.setFrozenRows(1);}ensureCols_(sh,head.length,head);return sh;}
const JOURNAL_HEAD_=['المعرف','العملية','بواسطة','الوقت','الطلب','قبل','الحالة','النتيجة','بعد'];
function journal_(){return table_('سجل العمليات',JOURNAL_HEAD_);}
function journalRow_(id){const sh=journal_(),n=sh.getLastRow();if(n<2)return -1;const v=sh.getRange(2,1,n-1,1).getValues();const i=v.findIndex(r=>String(r[0])===id);return i<0?-1:i+2;}
function act_(p,role,action){
  if(['put','del','propose','approve','reject','dismiss','cancel','close','close-del','reopen','prop-put','prop-del','cfg'].indexOf(action)<0)return actCore_(p,role,action);
  // The outer dispatcher holds the script lock throughout version checks and mutation.
  const reqId=String(p.requestId||'');if(!/^[A-Za-z0-9_-]{16,80}$/.test(reqId))return {ok:false,error:'bad_request',detail:'request_id'};
  const payload=Object.assign({},p);delete payload.token;delete payload.pin;
  if(payload.tx){payload.tx=Object.assign({},payload.tx);delete payload.tx.createdAt;delete payload.tx.updatedAt;delete payload.tx._baseUpdatedAt;}
  const serialized=JSON.stringify({role,payload});if(serialized.length>48000)return {ok:false,error:'bad_request'};
  const ex=journalRow_(reqId),sh=journal_();
  if(ex>0){const r=sh.getRange(ex,1,1,9).getValues()[0];if(r[4]!==serialized)return {ok:false,error:'request_mismatch'};if(r[6]==='done'){try{return JSON.parse(r[7]);}catch(e){}}return {ok:false,error:'commit_uncertain'};}
  let txId=p.id||(p.tx&&p.tx.id),before=txId?currentTx_(txId):null,request=null;
  if(action==='put'||action==='del'||(action==='propose'&&p.op!=='close')){
    if(p.expectedVersion==null||!assertVersion_(txId,p.expectedVersion)){
      if(action==='put'&&sameTx_(before,p.tx))return {ok:true,tx:before,already:true};
      return {ok:false,error:'conflict'};
    }
    if(txId&&findRow_(txId)>0&&!before)return {ok:false,error:'conflict'}; // cancelled ids cannot be revived
    if(action==='propose'){
      const existing=readReqs_().find(r=>r.status==='pending'&&r.id===txId&&r.op===p.op);
      if(existing)return {ok:false,error:'conflict',detail:'pending_request'};
    }
  }
  if(action==='approve'){
    request=readReqs_().find(r=>r.rid===p.rid);
    if(request&&request.status==='pending'&&request.op!=='close'){
      txId=request.id;before=currentTx_(txId);
      if(!request.tx||request.tx._baseUpdatedAt==null||!assertVersion_(txId,request.tx._baseUpdatedAt))return {ok:false,error:'conflict',detail:'طلب قديم أو تغيرت الحركة؛ ألغ الطلب وأرسله مجددًا.'};
    }
  }
  const row=sh.getLastRow()+1;
  sh.getRange(row,1,1,9).setNumberFormat('@').setValues([[reqId,action,role,String(Date.now()),serialized,JSON.stringify(before),'pending','','']]);
  try{
    // Stored request version is assigned by the server, never trusted from tx._baseUpdatedAt.
    if(action==='propose'&&p.op!=='close'){
      if(p.op==='del')p.tx={id:p.id};
      p.tx._baseUpdatedAt=before?before.updatedAt:0;
    }
    let res=actCore_(p,role,action);
    const committed=res&&res.ok&&(action==='put'||action==='del'||(action==='approve'&&request&&request.status==='pending'&&request.op!=='close'));
    const after=txId?currentTx_(txId):null;
    if(committed){const kind=action==='del'||request&&request.op==='del'?'del':before?'edit':'new';queueNotice_(reqId,kind,after||before);}
    if(res&&res.ok&&action==='put')res.tx=after;
    sh.getRange(row,7,1,3).setValues([['done',JSON.stringify(res),JSON.stringify(after)]]);
    return res;
  }catch(e){sh.getRange(row,7).setValue('uncertain');Logger.log(String(e&&e.message||e));return {ok:false,error:'commit_uncertain'};}
}
function serverClosing_(c){
  const out=JSON.parse(JSON.stringify(c)),balances={bld:0,farm:0};
  // Matches the current client ledger: all non-historical transactions through cutoff, no invented opening balance.
  readAll_().filter(t=>!t.hist&&t.date.slice(0,10)<=c.date).forEach(t=>{if(!(t.acct in balances))return;const cents=Math.round(t.amount*100);balances[t.acct]+=t.kind==='dep'?cents:-cents;});
  out.accts=out.accts||{};['bld','farm'].forEach(k=>{out.accts[k]=Object.assign({},out.accts[k]||{},{close:balances[k]/100});});out.at=Date.now();return out;
}
const QUEUE_HEAD_=['معرف الحدث','القناة','المستلم','البيانات','الحالة','وقت الإنشاء','التفاصيل','وقت المعالجة'];
function queue_(){return table_('طابور الإشعارات',QUEUE_HEAD_);}
function noticeSnapshot_(kind,t){
  const totals={bld:0,farm:0};readAll_().filter(x=>!x.hist).forEach(x=>{if(x.acct in totals)totals[x.acct]+=Math.round(x.amount*100)*(x.kind==='dep'?1:-1);});
  const what=(kind==='edit'?'تعديل ':kind==='del'?'إلغاء ':'')+(KIND_AR[t.kind]||'حركة')+' – '+(ACCT_AR[t.acct]||'');
  return {what,amount:Number(t.amount).toFixed(2),detail:[t.from,t.note].filter(Boolean).join(' · '),date:t.date,bld:(totals.bld/100).toFixed(2),farm:(totals.farm/100).toFixed(2),alloc:t.alloc||{},txId:t.id};
}
function queueNotice_(event,kind,t){
  if(!t)return;const sh=queue_(),cfg=readCfg_(),w=waConf_(),snap=noticeSnapshot_(kind,t),rows=[],now=String(Date.now());
  if(cfg.auto&&cfg.emails.length)rows.push([event,'email','configured',JSON.stringify({snapshot:snap,emails:cfg.emails}), 'pending',now,'','']);
  if(w.auto&&w.token&&w.phoneId&&w.tpl==='APPROVED')HEIRS.filter(id=>cfg.phones[id]).forEach(id=>rows.push([event+':'+id,'wa',cfg.phones[id],JSON.stringify({snapshot:snap,heir:id}), 'pending',now,'','']));
  if(rows.length)sh.getRange(sh.getLastRow()+1,1,rows.length,8).setNumberFormat('@').setValues(rows);
}
function installNotificationTrigger_(){
  ScriptApp.getProjectTriggers().filter(t=>t.getHandlerFunction()==='processNotifications_').forEach(t=>ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('processNotifications_').timeBased().everyMinutes(1).create();
}
function processNotifications_(){
  const lock=LockService.getScriptLock();if(!lock.tryLock(5000))return;
  let jobs=[];
  try{const sh=queue_(),n=sh.getLastRow();if(n<2)return;sh.getRange(2,1,n-1,8).getValues().forEach((r,i)=>{if(r[4]==='pending'&&jobs.length<10){sh.getRange(i+2,5).setValue('sending');jobs.push({row:i+2,r});}});}finally{lock.releaseLock();}
  jobs.forEach(job=>{
    let status='unknown',detail='';
    try{
      const data=JSON.parse(job.r[3]),s=data.snapshot;
      if(job.r[1]==='email'){
        if(MailApp.getRemainingDailyQuota()<data.emails.length+1){status='failed';detail='email_quota';}
        else{MailApp.sendEmail({to:Session.getEffectiveUser().getEmail(),bcc:data.emails.join(','),subject:'وريث: '+s.what,body:s.what+'\nالمبلغ: '+s.amount+' د.إ\n'+s.detail+'\nالتاريخ: '+s.date+'\nالرصيد الدفتري: البناية '+s.bld+'، المزارع '+s.farm,name:'تطبيق وريث'});status='accepted';detail='email_submitted';}
      }else{
        const w=waConf_();if(!w.auto||!w.token||w.tpl!=='APPROVED'){status='failed';detail='whatsapp_off';}
        else{let d=s.detail;if(s.alloc[data.heir]!=null)d+=' · نصيبك: '+Number(s.alloc[data.heir]).toFixed(2)+' درهم';
          const req=waTemplateMsg_(w,String(job.r[2]),[HEIR_NAMES[HEIRS.indexOf(data.heir)],waTxt_(s.what,120),waTxt_(s.amount,40),waTxt_(d,250),waTxt_(s.date,60),waTxt_(s.bld,40),waTxt_(s.farm,40)]);
          const response=UrlFetchApp.fetch(req.url,req);let j={};try{j=JSON.parse(response.getContentText());}catch(e){}
          if(response.getResponseCode()===200&&j.messages&&j.messages[0]){status='accepted';detail=j.messages[0].id;}else{status='failed';detail=waErrAr_(j.error);}
        }
      }
    }catch(e){detail='النتيجة غير مؤكدة؛ راجع المزود قبل إعادة الإرسال.';}
    const writeLock=LockService.getScriptLock();if(!writeLock.tryLock(5000))return;
    try{queue_().getRange(job.row,5).setValue(status);queue_().getRange(job.row,7,1,2).setValues([[safeText_(detail,500),String(Date.now())]]);}finally{writeLock.releaseLock();}
  });
}

function revisionOf_(id){const row=findRow_(id);return Math.max(Date.now(),row>0?(Number(sheet_().getRange(row,10).getValue())||0)+1:0);}

// Run manually from the editor before replacing an existing deployment.
function backupBeforeUpgrade_(){const copy=ss_().copy('وريث – نسخة احتياطية '+Utilities.formatDate(new Date(),'Asia/Dubai','yyyy-MM-dd HH:mm'));Logger.log('النسخة الاحتياطية: '+copy.getId());}
