const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/index.html');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end(html);});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:1});
let requests=[],txs=[{id:'demo1',date:'2026-10-08T10:00',acct:'bld',kind:'dep',amount:12500,from:'مثال إيجار',note:'بيانات اختبار',createdAt:1,updatedAt:1}],role='admin';const ids=['may','rashed','saeed','ali','eid','mohamed','naser','bakheeta','hamda','shamma','madhheya','noura'],names=['مي','راشد','سعيد','علي','عيد','محمد','ناصر','بخيتة','حمدة','شمة','مضحية','نورة'];
const payload=()=>({ok:true,v:6,role,txs,reqs:[],lock:'',props:[{id:'bld',acct:'bld',name:'عقار تجريبي',area:325}],meta:{heirs:ids.map((id,i)=>({id,n:names[i],full:names[i]+' تجريبي'}))},cfg:role==='admin'?{auto:false,emails:[],wa:{ready:false}}:undefined});
let errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.route('https://script.google.com/**',async route=>{const p=JSON.parse(route.request().postData());requests.push(p);let data;if(p.action==='login')data={ok:true,v:6,token:'a'.repeat(64),role};else if(p.action==='list')data=payload();else if(p.action==='put'){const t={...p.tx,updatedAt:Date.now()};txs.push(t);data={ok:true,tx:t};}else data={ok:true};await route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify(data)});});
await page.goto(base);await page.locator('#lPin').fill('12345678');await page.locator('[data-act="login"]').click();await page.locator('.home').waitFor();
assert.equal(requests[0].action,'login');assert.equal(requests[0].pin,'12345678');assert(requests.slice(1).every(r=>!r.pin));assert(!await page.evaluate(()=>localStorage.getItem('wareeth-auth').includes('12345678')));
assert.equal(await page.locator('nav.tabs button').count(),4);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
await page.screenshot({path:__dirname+'/preview-mobile.png',fullPage:true});
await page.locator('[data-tab="moves"]').click();await page.locator('#app').getByText('مثال إيجار',{exact:false}).first().waitFor();
await page.locator('[data-tab="me"]').click();assert((await page.locator('#app').innerText()).length>20);
await page.locator('[data-tab="props"]').click();await page.locator('#app').getByText('عقار تجريبي',{exact:false}).first().waitFor();
await page.locator('[data-tab="home"]').click();
// Form is opened through existing navigation, preserving application behavior.
await page.locator('[data-go="acct"]').first().click();const dep=page.locator('[data-new="dep"]');
if(await dep.count()){await dep.click();}else{await page.evaluate(()=>{state.form=newForm('dep','bld');state.stack.push({v:'form'});render();});}
await page.locator('#fAmt').fill('12abc');await page.locator('[data-act="save"]').click();assert((await page.locator('#fErr').innerText()).includes('مبلغ'));
await page.locator('#fAmt').fill('250.50');await page.locator('[data-act="save"]').click();await page.waitForTimeout(100);assert(requests.some(r=>r.action==='put'&&r.requestId&&r.expectedVersion===0));assert.equal(txs.length,2);
await page.evaluate(()=>document.querySelectorAll('.modal-bg').forEach(x=>x.remove()));
await page.evaluate(()=>logout());await page.locator('#lPin').waitFor();role='view';await page.locator('#lPin').fill('23456789');await page.locator('[data-act="login"]').click();await page.locator('.home').waitFor();await page.locator('[data-go="acct"]').first().click();assert.equal(await page.locator('[data-new]').count(),0);
assert.deepEqual(errors,[]);await browser.close();server.close();console.log('UI checks passed: mobile layout, 4 tabs, transient authentication, malformed amount, write request ids, view-only access, no runtime errors.');
})().catch(e=>{console.error(e);server.close();process.exit(1);});
