const fs=require('fs'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const html=fs.readFileSync(__dirname+'/index.html','utf8'),source=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]).join('\n');
const nodes=new Map();function el(id){const x={id,value:'',innerHTML:'',textContent:'',hidden:false,disabled:false,style:{setProperty(){}},classList:{add(){},remove(){},toggle(){}},dataset:{},offsetHeight:60,clientHeight:800,setAttribute(){},addEventListener(){},focus(){},getBoundingClientRect:()=>({height:400,bottom:400,top:0})};nodes.set(id,x);return x;}
['app','hTitle','hLeft','hRight','scroller','toast','prog','header','nav'].forEach(el);
const nav=['home','moves','me','props'].map(v=>({...el('tab_'+v),dataset:{tab:v}}));const ls=new Map([['wareeth-auth',JSON.stringify({pin:'old-secret',url:'https://script.google.com/macros/s/test/exec',custom:true,apiRevision:'2026.10.08.6'})]]),requests=[];
let txs=[];const ids=['may','rashed','saeed','ali','eid','mohamed','naser','bakheeta','hamda','shamma','madhheya','noura'];
const payload=()=>({ok:true,v:6,role:'admin',txs,lock:'',reqs:[],props:[{id:'bld',acct:'bld',name:'تجريبي',plot:'<img onerror=alert(1)>',area:123}],meta:{heirs:ids.map(id=>({id,n:id,full:id}))},cfg:{auto:false,emails:[]}});
let count=0,failFirst=false;const ctx=vm.createContext({console,URL,Blob,AbortController,crypto:{randomUUID:crypto.randomUUID},innerWidth:390,window:{addEventListener(){},matchMedia:()=>({matches:true})},matchMedia:()=>({matches:true}),location:{origin:'https://example.test',pathname:'/',search:'',hash:''},history:{replaceState(){}},localStorage:{getItem:k=>ls.get(k)??null,setItem:(k,v)=>ls.set(k,v),removeItem:k=>ls.delete(k)},document:{visibilityState:'visible',documentElement:{style:{setProperty(){}}},body:{classList:{toggle(){}},contains:()=>true,appendChild(){}},getElementById:id=>nodes.get(id)||null,querySelector:q=>q==='nav.tabs'?nodes.get('nav'):q==='header.bar'?nodes.get('header'):null,querySelectorAll:q=>q==='nav.tabs button'?nav:[],addEventListener(){},createElement:()=>el('generated')},setInterval(){},setTimeout(){return 1;},clearTimeout(){},fetch:async(url,o)=>{const p=JSON.parse(o.body);requests.push(p);if(p.action==='login')return {text:async()=>JSON.stringify({ok:true,token:'a'.repeat(64)})};if(p.action==='put'){if(failFirst){failFirst=false;throw Error('network');}const t={...p.tx,updatedAt:99};txs=[...txs.filter(x=>x.id!==t.id),t];return {text:async()=>JSON.stringify({ok:true,tx:t})};}return {text:async()=>JSON.stringify(payload())};}});
vm.runInContext(source,ctx);const run=s=>vm.runInContext(s,ctx),check=(s,fn)=>{fn();count++;console.log('PASS '+s);};
(async()=>{
check('Old persistent PIN removed',()=>assert(!ls.get('wareeth-auth').includes('old-secret')));
check('No historic financial data in public HTML',()=>assert(!html.includes('y25-fd-01')&&!html.includes('g-h-06')));
check('Four navigation tabs configured',()=>assert.equal(run('TABS.length'),4));
check('Strict Arabic and grouped amount parsing',()=>{assert.equal(run("parseAmt('١٢٬٥٠٠٫٥٠')"),12500.5);assert(Number.isNaN(run("parseAmt('12abc')")));assert(Number.isNaN(run("parseAmt('1.001')")));});
check('CSV formula injection escaped',()=>assert.equal(run("csvCell(' =HYPERLINK(\"x\")')").charAt(0),"'"));
el('lPin').value='12345678';el('lErr');await ctx.login({disabled:false});
check('Login sends PIN only at authentication',()=>{assert.equal(requests[0].action,'login');assert(requests[0].pin);assert(requests.slice(1).every(p=>!p.pin));});
check('Token and PIN not persisted',()=>assert(!ls.get('wareeth-auth').includes('aaaa')&&!ls.get('wareeth-auth').includes('12345678')));
check('Server property text rendered safely',()=>{const s=run('V.props().html');assert(s.includes('&lt;img'));assert(!s.includes('<img onerror'));});
check('Main screens render',()=>{for(const v of ['home','moves','me','props','settings','total','heirs'])assert(run(`V.${v}(${v==='moves'?'{}':''}).html`).length>20);});
run("state.form=newForm('dep','bld');state.stack=[{v:'home'},{v:'form'}];");el('fAmt').value='12abc';el('fDate').value='2026-10-08T10:00';el('fNote');el('fErr');
await ctx.save({disabled:false});check('Invalid amount prevents write',()=>assert(!requests.some(p=>p.action==='put')));
nodes.get('fAmt').value='25.50';failFirst=true;await ctx.save({disabled:false});const failed=requests.find(p=>p.action==='put');await ctx.save({disabled:false});const saved=requests.filter(p=>p.action==='put').at(-1);
check('Retry retains same operation and transaction identifiers',()=>{assert.equal(saved.requestId,failed.requestId);assert.equal(saved.tx.id,failed.tx.id);assert.equal(saved.expectedVersion,0);});
check('Saved transaction uses server modification version',()=>assert.equal(run('state.txs[0].updatedAt'),99));
run("store.canWrite=false;store.isAgent=false;");check('View-only account cannot show write controls',()=>assert(!run("V.acct({k:'bld'}).html").includes('data-new=')));
console.log(count+' client checks passed in a simulated DOM. Visual browser verification not performed.');
})().catch(e=>{console.error(e);process.exit(1);});
